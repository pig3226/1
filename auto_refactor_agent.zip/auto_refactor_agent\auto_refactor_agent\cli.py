from __future__ import annotations

import argparse
from pathlib import Path

from .agent import AutoRefactorAgent
from .config import AgentConfig
from .patcher import SafePatcher
from .report import patches_to_markdown, plan_to_json, plan_to_markdown, test_to_markdown
from .runner import TestRunner
from .scanner import CodeScanner
from .self_check import self_check_project


def main(argv: list[str] | None = None) -> int:
    parser = argparse.ArgumentParser(prog="auto-refactor-agent")
    subparsers = parser.add_subparsers(dest="command", required=True)

    scan_parser = subparsers.add_parser("scan", help="Scan a Python project for refactoring issues.")
    _add_common(scan_parser)
    scan_parser.add_argument("--json", action="store_true", help="Print raw JSON.")

    plan_parser = subparsers.add_parser("plan", help="Build a refactoring plan.")
    _add_common(plan_parser)
    plan_parser.add_argument("--use-ai", action="store_true", help="Ask an OpenAI-compatible model to review the plan.")
    plan_parser.add_argument("--json", action="store_true", help="Print raw JSON.")

    apply_parser = subparsers.add_parser("apply", help="Apply deterministic safe refactors.")
    _add_common(apply_parser)
    apply_parser.add_argument("--dry-run", action="store_true", help="Show patches without writing files.")

    run_parser = subparsers.add_parser("run", help="Scan, plan, optionally patch, and optionally run tests.")
    _add_common(run_parser)
    run_parser.add_argument("--use-ai", action="store_true")
    run_parser.add_argument("--apply", action="store_true", help="Write safe patches.")
    run_parser.add_argument("--dry-run", action="store_true", help="Preview patches without writing.")
    run_parser.add_argument("--test-cmd", help="Command to run after patches are applied.")

    test_parser = subparsers.add_parser("test", help="Run a test command from the target root.")
    test_parser.add_argument("root")
    test_parser.add_argument("--test-cmd", required=True)

    self_parser = subparsers.add_parser("self-check", help="Run syntax, structure, and AI-smell checks.")
    self_parser.add_argument("root", nargs="?", default=".")

    args = parser.parse_args(argv)

    if args.command == "test":
        result = TestRunner(Path(args.root).resolve()).run(args.test_cmd)
        print(test_to_markdown(result))
        return 0 if result.passed else result.return_code

    if args.command == "self-check":
        messages = self_check_project(Path(args.root).resolve())
        if messages:
            print("\n".join(messages))
            return 1
        print("Self-check passed.")
        return 0

    config = _config_from_args(args)

    if args.command == "scan":
        issues = CodeScanner(config).scan()
        plan = AutoRefactorAgent(config).planner.build_plan(issues)
        print(plan_to_json(plan) if args.json else plan_to_markdown(plan))
        return 0

    if args.command == "plan":
        plan = AutoRefactorAgent(config).scan()
        print(plan_to_json(plan) if args.json else plan_to_markdown(plan))
        return 0

    if args.command == "apply":
        issues = CodeScanner(config).scan()
        plan = AutoRefactorAgent(config).planner.build_plan(issues)
        results = SafePatcher().apply(plan.safe_actions, dry_run=args.dry_run)
        print(patches_to_markdown(results))
        return 0

    if args.command == "run":
        result = AutoRefactorAgent(config).run()
        print(plan_to_markdown(result.plan))
        print()
        print(patches_to_markdown(result.patches))
        print()
        print(test_to_markdown(result.tests))
        return 0 if result.tests is None or result.tests.passed else result.tests.return_code

    parser.error(f"Unknown command: {args.command}")
    return 2


def _add_common(parser: argparse.ArgumentParser) -> None:
    parser.add_argument("root", help="Target project root.")
    parser.add_argument("--max-function-lines", type=int, default=60)
    parser.add_argument("--max-complexity", type=int, default=12)
    parser.add_argument("--include-tests", action="store_true")


def _config_from_args(args: argparse.Namespace) -> AgentConfig:
    return AgentConfig.from_root(
        args.root,
        max_function_lines=args.max_function_lines,
        max_complexity=args.max_complexity,
        include_tests=args.include_tests,
        use_ai=getattr(args, "use_ai", False),
        apply_changes=getattr(args, "apply", False),
        dry_run=getattr(args, "dry_run", False),
        test_cmd=getattr(args, "test_cmd", None),
    )

