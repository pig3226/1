from __future__ import annotations

import ast
from collections import defaultdict
from pathlib import Path

from .config import AgentConfig
from .models import CodeIssue, IssueKind, Severity


IGNORED_DIRS = {
    ".git",
    ".hg",
    ".mypy_cache",
    ".pytest_cache",
    ".ruff_cache",
    "__pycache__",
    "build",
    "dist",
    ".venv",
    "venv",
    "node_modules",
}


class CodeScanner:
    def __init__(self, config: AgentConfig) -> None:
        self.config = config

    def scan(self) -> list[CodeIssue]:
        issues: list[CodeIssue] = []
        for file in self._python_files():
            issues.extend(self._scan_file(file))
        issues.extend(self._scan_duplicates())
        return sorted(issues, key=lambda item: (str(item.file), item.line, item.kind.value))

    def _python_files(self) -> list[Path]:
        files: list[Path] = []
        for path in self.config.root.rglob("*.py"):
            if any(part in IGNORED_DIRS for part in path.parts):
                continue
            if not self.config.include_tests and self._looks_like_test(path):
                continue
            files.append(path)
        return sorted(files)

    @staticmethod
    def _looks_like_test(path: Path) -> bool:
        lowered = str(path).lower()
        return "\\tests\\" in lowered or "/tests/" in lowered or path.name.startswith("test_")

    def _scan_file(self, file: Path) -> list[CodeIssue]:
        try:
            source = file.read_text(encoding="utf-8")
            tree = ast.parse(source, filename=str(file))
        except (SyntaxError, UnicodeDecodeError) as exc:
            return [
                CodeIssue(
                    kind=IssueKind.COMPLEX_FUNCTION,
                    file=file,
                    line=getattr(exc, "lineno", 1) or 1,
                    message=f"File could not be parsed: {exc}",
                    severity=Severity.HIGH,
                )
            ]

        visitor = _IssueVisitor(file=file, source=source, config=self.config)
        visitor.visit(tree)
        return visitor.issues

    def _scan_duplicates(self) -> list[CodeIssue]:
        normalized: dict[str, list[tuple[Path, int]]] = defaultdict(list)
        for file in self._python_files():
            try:
                lines = file.read_text(encoding="utf-8").splitlines()
            except UnicodeDecodeError:
                continue
            for index, line in enumerate(lines, start=1):
                stripped = line.strip()
                if not stripped or stripped.startswith("#") or len(stripped) < 12:
                    continue
                normalized[stripped].append((file, index))

        issues: list[CodeIssue] = []
        for line_text, locations in normalized.items():
            if len(locations) < self.config.min_duplicate_lines:
                continue
            first_file, first_line = locations[0]
            issues.append(
                CodeIssue(
                    kind=IssueKind.DUPLICATE_LINES,
                    file=first_file,
                    line=first_line,
                    message=f"Line appears {len(locations)} times and may hide duplicated logic.",
                    severity=Severity.LOW,
                    details={"line": line_text, "locations": [(str(path), line) for path, line in locations]},
                )
            )
        return issues


class _IssueVisitor(ast.NodeVisitor):
    def __init__(self, file: Path, source: str, config: AgentConfig) -> None:
        self.file = file
        self.source = source
        self.config = config
        self.issues: list[CodeIssue] = []

    def visit_FunctionDef(self, node: ast.FunctionDef) -> None:
        self._check_function(node)
        self.generic_visit(node)

    def visit_AsyncFunctionDef(self, node: ast.AsyncFunctionDef) -> None:
        self._check_function(node)
        self.generic_visit(node)

    def visit_ExceptHandler(self, node: ast.ExceptHandler) -> None:
        if node.type is None:
            self.issues.append(
                CodeIssue(
                    kind=IssueKind.BARE_EXCEPT,
                    file=self.file,
                    line=node.lineno,
                    message="Bare except catches BaseException and can hide interrupts or exits.",
                    severity=Severity.HIGH,
                )
            )
        elif isinstance(node.type, ast.Name) and node.type.id == "Exception":
            self.issues.append(
                CodeIssue(
                    kind=IssueKind.BROAD_EXCEPT,
                    file=self.file,
                    line=node.lineno,
                    message="Broad Exception handler should usually be narrowed or logged.",
                    severity=Severity.MEDIUM,
                )
            )
        self.generic_visit(node)

    def visit_Call(self, node: ast.Call) -> None:
        if isinstance(node.func, ast.Name) and node.func.id == "print":
            self.issues.append(
                CodeIssue(
                    kind=IssueKind.PRINT_DEBUG,
                    file=self.file,
                    line=node.lineno,
                    message="Debug print found; prefer structured logging for production code.",
                    severity=Severity.LOW,
                )
            )
        self.generic_visit(node)

    def _check_function(self, node: ast.FunctionDef | ast.AsyncFunctionDef) -> None:
        end_lineno = getattr(node, "end_lineno", node.lineno)
        length = max(1, end_lineno - node.lineno + 1)
        if length > self.config.max_function_lines:
            self.issues.append(
                CodeIssue(
                    kind=IssueKind.LONG_FUNCTION,
                    file=self.file,
                    line=node.lineno,
                    message=f"Function has {length} lines; consider extracting smaller functions.",
                    severity=Severity.MEDIUM,
                    symbol=node.name,
                    details={"line_count": length},
                )
            )

        complexity = _cyclomatic_complexity(node)
        if complexity > self.config.max_complexity:
            self.issues.append(
                CodeIssue(
                    kind=IssueKind.COMPLEX_FUNCTION,
                    file=self.file,
                    line=node.lineno,
                    message=f"Function complexity is {complexity}; split branches or extract policies.",
                    severity=Severity.MEDIUM,
                    symbol=node.name,
                    details={"complexity": complexity},
                )
            )

        defaults = list(node.args.defaults)
        args = list(node.args.args)
        default_offset = len(args) - len(defaults)
        for offset, default in enumerate(defaults):
            if isinstance(default, (ast.List, ast.Dict, ast.Set)):
                arg = args[default_offset + offset]
                self.issues.append(
                    CodeIssue(
                        kind=IssueKind.MUTABLE_DEFAULT,
                        file=self.file,
                        line=node.lineno,
                        message=f"Argument '{arg.arg}' uses a mutable default value.",
                        severity=Severity.HIGH,
                        symbol=node.name,
                        details={"arg_name": arg.arg},
                    )
                )


def _cyclomatic_complexity(node: ast.AST) -> int:
    complexity = 1
    branch_nodes = (
        ast.If,
        ast.For,
        ast.AsyncFor,
        ast.While,
        ast.Try,
        ast.ExceptHandler,
        ast.With,
        ast.AsyncWith,
        ast.IfExp,
        ast.BoolOp,
        ast.Match,
    )
    for child in ast.walk(node):
        if isinstance(child, branch_nodes):
            complexity += 1
        elif isinstance(child, ast.comprehension):
            complexity += 1
    return complexity

