from __future__ import annotations

import subprocess
from pathlib import Path

from .models import TestResult


class TestRunner:
    def __init__(self, cwd: Path) -> None:
        self.cwd = cwd

    def run(self, command: str) -> TestResult:
        completed = subprocess.run(
            command,
            cwd=self.cwd,
            shell=True,
            text=True,
            capture_output=True,
            timeout=300,
        )
        return TestResult(
            command=command,
            return_code=completed.returncode,
            stdout=completed.stdout,
            stderr=completed.stderr,
        )

