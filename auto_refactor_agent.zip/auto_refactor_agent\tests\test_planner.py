from pathlib import Path
import unittest

from auto_refactor_agent.config import AgentConfig
from auto_refactor_agent.models import CodeIssue, IssueKind, Severity
from auto_refactor_agent.planner import RefactorPlanner


class PlannerTests(unittest.TestCase):
    def test_planner_marks_only_deterministic_changes_safe(self) -> None:
        issue = CodeIssue(
            kind=IssueKind.BARE_EXCEPT,
            file=Path("demo.py"),
            line=10,
            message="bare except",
            severity=Severity.HIGH,
        )
        plan = RefactorPlanner(AgentConfig.from_root(".")).build_plan([issue])

        self.assertEqual(len(plan.safe_actions), 1)
        self.assertEqual(plan.safe_actions[0].patch_kind, "bare_except_to_exception")


if __name__ == "__main__":
    unittest.main()
