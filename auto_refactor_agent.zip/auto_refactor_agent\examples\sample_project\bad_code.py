def append_item(value, items=[]):
    items.append(value)
    return items


def noisy_parser(raw):
    print("parsing", raw)
    try:
        return int(raw)
    except:
        return 0


def repeated_one(user):
    score = user.get("score", 0)
    status = "active" if score > 10 else "new"
    return {"score": score, "status": status}


def repeated_two(user):
    score = user.get("score", 0)
    status = "active" if score > 10 else "new"
    return {"score": score, "status": status}

