from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path


@dataclass(frozen=True)
class AgentConfig:
    root: Path
    max_function_lines: int = 60
    max_complexity: int = 12
    min_duplicate_lines: int = 4
    include_tests: bool = False
    use_ai: bool = False
    apply_changes: bool = False
    dry_run: bool = False
    test_cmd: str | None = None

    @classmethod
    def from_root(cls, root: str | Path, **kwargs: object) -> "AgentConfig":
        return cls(root=Path(root).resolve(), **kwargs)

