from __future__ import annotations

import json
import os
import urllib.error
import urllib.request

from .models import CodeIssue


class AIReviewer:
    def __init__(self) -> None:
        self.api_key = os.getenv("OPENAI_API_KEY")
        self.base_url = os.getenv("OPENAI_BASE_URL", "https://api.openai.com/v1").rstrip("/")
        self.model = os.getenv("OPENAI_MODEL", "gpt-4.1-mini")

    @property
    def available(self) -> bool:
        return bool(self.api_key)

    def review(self, issues: list[CodeIssue]) -> str:
        if not self.available:
            return "AI review skipped: OPENAI_API_KEY is not set."

        sample = [issue.as_dict() for issue in issues[:40]]
        payload = {
            "model": self.model,
            "messages": [
                {
                    "role": "system",
                    "content": "You are a senior refactoring reviewer. Prioritize safety, tests, and small reversible changes.",
                },
                {
                    "role": "user",
                    "content": "Review these static-analysis findings and identify the safest first changes:\n"
                    + json.dumps(sample, ensure_ascii=False, indent=2),
                },
            ],
            "temperature": 0.2,
        }
        request = urllib.request.Request(
            f"{self.base_url}/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {self.api_key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        try:
            with urllib.request.urlopen(request, timeout=60) as response:
                data = json.loads(response.read().decode("utf-8"))
            return data["choices"][0]["message"]["content"]
        except (urllib.error.URLError, KeyError, IndexError, json.JSONDecodeError) as exc:
            return f"AI review failed: {exc}"

