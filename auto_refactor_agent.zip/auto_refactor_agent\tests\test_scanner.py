from pathlib import Path
import unittest

from auto_refactor_agent.config import AgentConfig
from auto_refactor_agent.models import IssueKind
from auto_refactor_agent.scanner import CodeScanner


class ScannerTests(unittest.TestCase):
    def test_scanner_finds_core_issues(self) -> None:
        root = Path(__file__).resolve().parents[1] / "examples" / "sample_project"
        issues = CodeScanner(AgentConfig.from_root(root)).scan()
        kinds = {issue.kind for issue in issues}

        self.assertIn(IssueKind.BARE_EXCEPT, kinds)
        self.assertIn(IssueKind.MUTABLE_DEFAULT, kinds)
        self.assertIn(IssueKind.PRINT_DEBUG, kinds)


if __name__ == "__main__":
    unittest.main()
