from __future__ import annotations

import json

from .models import PatchResult, RefactorPlan, TestResult


def plan_to_json(plan: RefactorPlan) -> str:
    return json.dumps(plan.as_dict(), ensure_ascii=False, indent=2)


def plan_to_markdown(plan: RefactorPlan) -> str:
    lines = [
        "# Refactor Plan",
        "",
        f"Root: `{plan.root}`",
        f"Issues: {len(plan.issues)}",
        f"Actions: {len(plan.actions)}",
        f"Safe actions: {len(plan.safe_actions)}",
        "",
    ]
    if plan.ai_review:
        lines.extend(["## AI Review", "", plan.ai_review, ""])

    lines.extend(["## Actions", ""])
    for index, action in enumerate(plan.actions, start=1):
        safety = "safe" if action.safe_to_apply else "manual"
        lines.append(f"{index}. [{safety}] {action.title}")
        lines.append(f"   - File: `{action.file}`")
        lines.append(f"   - Line: {action.line}")
        lines.append(f"   - Reason: {action.rationale}")
    return "\n".join(lines)


def patches_to_markdown(results: list[PatchResult]) -> str:
    if not results:
        return "No patchable actions found."
    lines: list[str] = ["# Patch Results", ""]
    for result in results:
        lines.append(f"## {result.file}")
        lines.append(result.message)
        if result.preview:
            lines.append("")
            lines.append("```diff")
            lines.append(result.preview.rstrip())
            lines.append("```")
        lines.append("")
    return "\n".join(lines)


def test_to_markdown(result: TestResult | None) -> str:
    if result is None:
        return "No test command configured."
    status = "passed" if result.passed else "failed"
    return "\n".join(
        [
            "# Test Result",
            "",
            f"Command: `{result.command}`",
            f"Status: {status}",
            f"Return code: {result.return_code}",
            "",
            "## stdout",
            "```text",
            result.stdout.strip(),
            "```",
            "",
            "## stderr",
            "```text",
            result.stderr.strip(),
            "```",
        ]
    )

