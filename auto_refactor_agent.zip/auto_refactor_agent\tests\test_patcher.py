from pathlib import Path
import unittest

from auto_refactor_agent.models import IssueKind, RefactorAction
from auto_refactor_agent.patcher import SafePatcher


class PatcherTests(unittest.TestCase):
    def test_patcher_replaces_bare_except(self) -> None:
        with self._temp_file("try:\n    x = 1\nexcept:\n    x = 2\n") as file:
            action = RefactorAction(
                title="replace",
                file=file,
                line=3,
                issue_kind=IssueKind.BARE_EXCEPT,
                rationale="safer",
                safe_to_apply=True,
                patch_kind="bare_except_to_exception",
            )

            results = SafePatcher().apply([action])

            self.assertTrue(results[0].changed)
            self.assertIn("except Exception:", file.read_text(encoding="utf-8"))
            self.assertIn("except Exception:\n    x = 2", file.read_text(encoding="utf-8"))

    def test_patcher_replaces_mutable_default(self) -> None:
        with self._temp_file("def add(value, items=[]):\n    items.append(value)\n    return items\n") as file:
            action = RefactorAction(
                title="replace",
                file=file,
                line=1,
                issue_kind=IssueKind.MUTABLE_DEFAULT,
                rationale="safe",
                safe_to_apply=True,
                patch_kind="mutable_default_to_none",
                metadata={"arg_name": "items", "symbol": "add"},
            )

            results = SafePatcher().apply([action])
            updated = file.read_text(encoding="utf-8")

            self.assertTrue(results[0].changed)
            self.assertIn("items=None", updated)
            self.assertIn("if items is None:", updated)

    def _temp_file(self, content: str):
        import tempfile
        from contextlib import contextmanager

        @contextmanager
        def manager():
            with tempfile.TemporaryDirectory() as temp_dir:
                file = Path(temp_dir) / "demo.py"
                file.write_text(content, encoding="utf-8")
                yield file

        return manager()


if __name__ == "__main__":
    unittest.main()
