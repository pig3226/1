import unittest

from bad_code import append_item, noisy_parser


class BadCodeTests(unittest.TestCase):
    def test_parser(self):
        self.assertEqual(noisy_parser("3"), 3)
        self.assertEqual(noisy_parser("x"), 0)

    def test_append_item_current_behavior(self):
        self.assertEqual(append_item("a", []), ["a"])


if __name__ == "__main__":
    unittest.main()

