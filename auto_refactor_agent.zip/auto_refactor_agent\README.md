# Auto Refactor Agent

一个可本地运行的自动化代码重构 Agent 示例项目。它面向 Python 仓库，包含代码扫描、风险识别、重构计划生成、安全补丁应用、测试闭环和可选 AI 评审接口。

## 能力

- 扫描 Python 文件并识别常见技术债：
  - 过长函数
  - 过复杂函数
  - 裸 `except`
  - 过宽泛 `except Exception`
  - 可变默认参数
  - 调试 `print`
  - 重复代码行
- 生成结构化重构计划。
- 自动应用低风险补丁：
  - `except:` 改为 `except Exception:`
  - `def fn(x=[]):` 改为 `def fn(x=None):` 并插入初始化逻辑
- 运行测试命令，失败后保留报告。
- 可选接入 OpenAI 或其他兼容服务，用于对计划进行二次评审。

## 快速开始

```powershell
cd auto_refactor_agent
python -m auto_refactor_agent scan examples/sample_project
python -m auto_refactor_agent plan examples/sample_project
python -m auto_refactor_agent apply examples/sample_project --dry-run
python -m auto_refactor_agent run examples/sample_project --apply --test-cmd "python -m unittest discover -s examples/sample_project"
```

## 使用 AI 评审

默认不依赖 API Key。需要 AI 评审时设置环境变量：

```powershell
$env:OPENAI_API_KEY="你的 key"
python -m auto_refactor_agent run examples/sample_project --use-ai
```

也可以指定兼容 OpenAI Chat Completions 的接口：

```powershell
$env:OPENAI_BASE_URL="https://api.openai.com/v1"
$env:OPENAI_MODEL="gpt-4.1-mini"
```

## 项目结构

```text
auto_refactor_agent/
  auto_refactor_agent/
    agent.py          # 主编排流程
    ai.py             # 可选 AI 评审适配器
    cli.py            # 命令行入口
    config.py         # 配置
    models.py         # 数据模型
    patcher.py        # 安全补丁应用
    planner.py        # 重构计划生成
    report.py         # 报告输出
    runner.py         # 测试命令运行器
    scanner.py        # AST 扫描器
    self_check.py     # 两轮自检
  examples/
  tests/
```

## 设计原则

这个项目特意把“自动化”和“安全边界”分开：扫描器和规划器可以提出很多建议，但补丁器只自动执行确定性强、可回滚、风险较低的修改。更复杂的重构会保留为人工审查建议，避免 Agent 直接大规模改坏业务代码。

