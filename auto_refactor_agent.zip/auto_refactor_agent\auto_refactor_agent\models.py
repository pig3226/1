from __future__ import annotations

from dataclasses import dataclass, field
from enum import Enum
from pathlib import Path
from typing import Any


class Severity(str, Enum):
    LOW = "low"
    MEDIUM = "medium"
    HIGH = "high"


class IssueKind(str, Enum):
    LONG_FUNCTION = "long_function"
    COMPLEX_FUNCTION = "complex_function"
    BARE_EXCEPT = "bare_except"
    BROAD_EXCEPT = "broad_except"
    MUTABLE_DEFAULT = "mutable_default"
    PRINT_DEBUG = "print_debug"
    DUPLICATE_LINES = "duplicate_lines"


@dataclass(frozen=True)
class CodeIssue:
    kind: IssueKind
    file: Path
    line: int
    message: str
    severity: Severity
    symbol: str | None = None
    details: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "kind": self.kind.value,
            "file": str(self.file),
            "line": self.line,
            "message": self.message,
            "severity": self.severity.value,
            "symbol": self.symbol,
            "details": self.details,
        }


@dataclass(frozen=True)
class RefactorAction:
    title: str
    file: Path
    line: int
    issue_kind: IssueKind
    rationale: str
    safe_to_apply: bool
    patch_kind: str | None = None
    metadata: dict[str, Any] = field(default_factory=dict)

    def as_dict(self) -> dict[str, Any]:
        return {
            "title": self.title,
            "file": str(self.file),
            "line": self.line,
            "issue_kind": self.issue_kind.value,
            "rationale": self.rationale,
            "safe_to_apply": self.safe_to_apply,
            "patch_kind": self.patch_kind,
            "metadata": self.metadata,
        }


@dataclass
class RefactorPlan:
    root: Path
    issues: list[CodeIssue]
    actions: list[RefactorAction]
    ai_review: str | None = None

    @property
    def safe_actions(self) -> list[RefactorAction]:
        return [action for action in self.actions if action.safe_to_apply]

    def as_dict(self) -> dict[str, Any]:
        return {
            "root": str(self.root),
            "issues": [issue.as_dict() for issue in self.issues],
            "actions": [action.as_dict() for action in self.actions],
            "ai_review": self.ai_review,
        }


@dataclass(frozen=True)
class PatchResult:
    file: Path
    changed: bool
    message: str
    preview: str | None = None


@dataclass(frozen=True)
class TestResult:
    command: str
    return_code: int
    stdout: str
    stderr: str

    @property
    def passed(self) -> bool:
        return self.return_code == 0

