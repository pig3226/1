from __future__ import annotations

import ast
from pathlib import Path


def self_check_project(root: Path) -> list[str]:
    messages: list[str] = []
    messages.extend(_syntax_check(root))
    messages.extend(_structure_check(root))
    messages.extend(_ai_smell_check(root))
    return messages


def _syntax_check(root: Path) -> list[str]:
    messages: list[str] = []
    for file in sorted(root.rglob("*.py")):
        if "__pycache__" in file.parts:
            continue
        try:
            ast.parse(file.read_text(encoding="utf-8"), filename=str(file))
        except Exception as exc:
            messages.append(f"syntax: {file}: {exc}")
    return messages


def _structure_check(root: Path) -> list[str]:
    required = [
        root / "README.md",
        root / "pyproject.toml",
        root / "auto_refactor_agent" / "cli.py",
        root / "auto_refactor_agent" / "agent.py",
        root / "auto_refactor_agent" / "scanner.py",
        root / "auto_refactor_agent" / "patcher.py",
    ]
    return [f"missing: {path}" for path in required if not path.exists()]


def _ai_smell_check(root: Path) -> list[str]:
    banned = [
        "as an " + "ai language model",
        "de" + "lve",
        "game-" + "changer",
        "seam" + "lessly",
        "robust " + "solution",
    ]
    messages: list[str] = []
    for file in sorted(root.rglob("*")):
        if file.is_dir() or file.suffix.lower() not in {".py", ".md", ".toml", ".txt"}:
            continue
        text = file.read_text(encoding="utf-8", errors="ignore").lower()
        for phrase in banned:
            if phrase in text:
                messages.append(f"ai-smell: {file} contains '{phrase}'")
    return messages
