from __future__ import annotations

from dataclasses import dataclass

from .ai import AIReviewer
from .config import AgentConfig
from .models import PatchResult, RefactorPlan, TestResult
from .patcher import SafePatcher
from .planner import RefactorPlanner
from .runner import TestRunner
from .scanner import CodeScanner


@dataclass
class AgentRunResult:
    plan: RefactorPlan
    patches: list[PatchResult]
    tests: TestResult | None


class AutoRefactorAgent:
    def __init__(self, config: AgentConfig) -> None:
        self.config = config
        self.scanner = CodeScanner(config)
        self.planner = RefactorPlanner(config)
        self.patcher = SafePatcher()
        self.test_runner = TestRunner(config.root)

    def scan(self) -> RefactorPlan:
        issues = self.scanner.scan()
        ai_review = None
        if self.config.use_ai:
            ai_review = AIReviewer().review(issues)
        return self.planner.build_plan(issues, ai_review=ai_review)

    def run(self) -> AgentRunResult:
        plan = self.scan()
        patches: list[PatchResult] = []
        tests: TestResult | None = None

        if self.config.apply_changes or self.config.dry_run:
            patches = self.patcher.apply(plan.safe_actions, dry_run=self.config.dry_run)

        if self.config.test_cmd and self.config.apply_changes and not self.config.dry_run:
            tests = self.test_runner.run(self.config.test_cmd)

        return AgentRunResult(plan=plan, patches=patches, tests=tests)

