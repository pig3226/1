from __future__ import annotations

import ast
import difflib
import re
from collections import defaultdict
from pathlib import Path

from .models import PatchResult, RefactorAction


class SafePatcher:
    def apply(self, actions: list[RefactorAction], dry_run: bool = False) -> list[PatchResult]:
        grouped: dict[Path, list[RefactorAction]] = defaultdict(list)
        for action in actions:
            if action.safe_to_apply and action.patch_kind:
                grouped[action.file].append(action)

        results: list[PatchResult] = []
        for file, file_actions in grouped.items():
            original = file.read_text(encoding="utf-8")
            updated = original
            for action in sorted(file_actions, key=lambda item: item.line, reverse=True):
                updated = self._apply_one(updated, action)

            if updated == original:
                results.append(PatchResult(file=file, changed=False, message="No safe change was applicable."))
                continue

            preview = _diff(original, updated, file)
            if not dry_run:
                file.write_text(updated, encoding="utf-8")
            results.append(
                PatchResult(
                    file=file,
                    changed=True,
                    message="Preview generated." if dry_run else "File updated.",
                    preview=preview,
                )
            )
        return results

    def _apply_one(self, source: str, action: RefactorAction) -> str:
        if action.patch_kind == "bare_except_to_exception":
            return _replace_bare_except(source, action.line)
        if action.patch_kind == "mutable_default_to_none":
            arg_name = action.metadata.get("arg_name")
            symbol = action.metadata.get("symbol")
            if isinstance(arg_name, str) and isinstance(symbol, str):
                return _replace_mutable_default(source, action.line, symbol, arg_name)
        return source


def _replace_bare_except(source: str, line_number: int) -> str:
    lines = source.splitlines(keepends=True)
    index = line_number - 1
    if index < 0 or index >= len(lines):
        return source
    line = lines[index]
    newline = "\r\n" if line.endswith("\r\n") else "\n" if line.endswith("\n") else ""
    body = line[: -len(newline)] if newline else line
    updated = re.sub(r"^(\s*)except\s*:\s*(#.*)?$", r"\1except Exception:\2", body)
    lines[index] = updated + newline
    return "".join(lines)


def _replace_mutable_default(source: str, line_number: int, symbol: str, arg_name: str) -> str:
    tree = ast.parse(source)
    target: ast.FunctionDef | ast.AsyncFunctionDef | None = None
    for node in ast.walk(tree):
        if isinstance(node, (ast.FunctionDef, ast.AsyncFunctionDef)) and node.name == symbol and node.lineno == line_number:
            target = node
            break
    if target is None:
        return source

    lines = source.splitlines(keepends=True)
    def_index = target.lineno - 1
    if def_index < 0 or def_index >= len(lines):
        return source

    line = lines[def_index]
    line = _replace_default_literal(line, arg_name)
    lines[def_index] = line

    insert_at = target.body[0].lineno - 1 if target.body else target.lineno
    body_indent = _line_indent(lines[insert_at]) if insert_at < len(lines) else _line_indent(lines[def_index]) + "    "
    initializer = f"{body_indent}if {arg_name} is None:\n{body_indent}    {arg_name} = []\n"

    body_source = "".join(lines[target.lineno : getattr(target, "end_lineno", target.lineno)])
    if f"if {arg_name} is None:" not in body_source:
        lines.insert(insert_at, initializer)
    return "".join(lines)


def _replace_default_literal(line: str, arg_name: str) -> str:
    patterns = [
        rf"({re.escape(arg_name)}\s*:\s*[^=,)]*=\s*)\[\]",
        rf"({re.escape(arg_name)}\s*=\s*)\[\]",
        rf"({re.escape(arg_name)}\s*:\s*[^=,)]*=\s*)\{{\}}",
        rf"({re.escape(arg_name)}\s*=\s*)\{{\}}",
        rf"({re.escape(arg_name)}\s*:\s*[^=,)]*=\s*)set\(\)",
        rf"({re.escape(arg_name)}\s*=\s*)set\(\)",
    ]
    for pattern in patterns:
        updated = re.sub(pattern, rf"\1None", line, count=1)
        if updated != line:
            return updated
    return line


def _line_indent(line: str) -> str:
    return line[: len(line) - len(line.lstrip())]


def _diff(original: str, updated: str, file: Path) -> str:
    return "".join(
        difflib.unified_diff(
            original.splitlines(keepends=True),
            updated.splitlines(keepends=True),
            fromfile=f"{file}:before",
            tofile=f"{file}:after",
        )
    )
