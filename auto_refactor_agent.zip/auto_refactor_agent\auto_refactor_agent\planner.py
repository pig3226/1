from __future__ import annotations

from .config import AgentConfig
from .models import CodeIssue, IssueKind, RefactorAction, RefactorPlan


class RefactorPlanner:
    def __init__(self, config: AgentConfig) -> None:
        self.config = config

    def build_plan(self, issues: list[CodeIssue], ai_review: str | None = None) -> RefactorPlan:
        actions = [self._action_for_issue(issue) for issue in issues]
        return RefactorPlan(root=self.config.root, issues=issues, actions=actions, ai_review=ai_review)

    def _action_for_issue(self, issue: CodeIssue) -> RefactorAction:
        if issue.kind == IssueKind.BARE_EXCEPT:
            return RefactorAction(
                title="Replace bare except with except Exception",
                file=issue.file,
                line=issue.line,
                issue_kind=issue.kind,
                rationale="Catching BaseException also catches KeyboardInterrupt and SystemExit. Exception is safer.",
                safe_to_apply=True,
                patch_kind="bare_except_to_exception",
            )
        if issue.kind == IssueKind.MUTABLE_DEFAULT:
            return RefactorAction(
                title="Replace mutable default argument with None sentinel",
                file=issue.file,
                line=issue.line,
                issue_kind=issue.kind,
                rationale="Mutable defaults are shared between calls and can leak state.",
                safe_to_apply=True,
                patch_kind="mutable_default_to_none",
                metadata={"arg_name": issue.details.get("arg_name"), "symbol": issue.symbol},
            )
        if issue.kind == IssueKind.LONG_FUNCTION:
            return RefactorAction(
                title="Extract smaller functions",
                file=issue.file,
                line=issue.line,
                issue_kind=issue.kind,
                rationale="Long functions mix responsibilities and are hard to test in isolation.",
                safe_to_apply=False,
                metadata={"symbol": issue.symbol},
            )
        if issue.kind == IssueKind.COMPLEX_FUNCTION:
            return RefactorAction(
                title="Reduce branch complexity",
                file=issue.file,
                line=issue.line,
                issue_kind=issue.kind,
                rationale="High branching makes behavior difficult to reason about and verify.",
                safe_to_apply=False,
                metadata={"symbol": issue.symbol},
            )
        if issue.kind == IssueKind.BROAD_EXCEPT:
            return RefactorAction(
                title="Narrow exception handling or add logging",
                file=issue.file,
                line=issue.line,
                issue_kind=issue.kind,
                rationale="The correct exception type is domain-specific, so this needs review.",
                safe_to_apply=False,
            )
        if issue.kind == IssueKind.PRINT_DEBUG:
            return RefactorAction(
                title="Replace print with logging",
                file=issue.file,
                line=issue.line,
                issue_kind=issue.kind,
                rationale="Logging level, logger name, and message context should follow the host project style.",
                safe_to_apply=False,
            )
        return RefactorAction(
            title="Review duplicated logic",
            file=issue.file,
            line=issue.line,
            issue_kind=issue.kind,
            rationale="Repeated logic may be extractable, but the right abstraction depends on domain meaning.",
            safe_to_apply=False,
        )

